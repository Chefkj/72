#ifndef DEGREEPROGRAM_H
#define DEGREEPROGRAM_H

#include <iostream>

using namespace std;

enum DegreeProgram{SECURITY, NETWORK, SOFTWARE};

#endif